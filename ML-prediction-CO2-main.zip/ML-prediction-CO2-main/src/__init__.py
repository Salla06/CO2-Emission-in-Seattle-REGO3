"""
Seattle Energy ML 2016 - Package Principal
Prédiction de la consommation énergétique des bâtiments de Seattle

ENSAE - Machine Learning 1
"""
